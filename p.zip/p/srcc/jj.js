const productBoxes = document.querySelectorAll('.product-box');

// Add event listeners for mouseenter and mouseleave
productBoxes.forEach((box) => {
  box.addEventListener('mouseenter', () => {
    box.classList.add('hovered');
  });

  box.addEventListener('mouseleave', () => {
    box.classList.remove('hovered');
  });
});